﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalaryLibrary
{
    public class SalaryCalculator
    {
        public decimal CalculateBasicSalary(decimal salary)
        {
            return salary;
        }
    }
}